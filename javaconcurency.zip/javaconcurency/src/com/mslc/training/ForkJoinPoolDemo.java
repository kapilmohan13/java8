package com.cignex.learning;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class ForkJoinPoolDemo {

	public static void main(String[] args) throws InterruptedException,
			ExecutionException {

		ForkJoinPool pool = new ForkJoinPool();

		pool.execute(new MyRecursiveAction());
		
		System.out.println("Task Submitted");
		Thread.sleep(7000);


	}

	private static class MyRecursiveAction extends RecursiveTask<List<String>> {

		private static int entries = 1;

		@Override
		protected List<String> compute() {

			List<String> results = new ArrayList<String>();
			List<MyRecursiveAction> tasks = new ArrayList<>();

			System.out.println("compute in  : "
					+ Thread.currentThread().getName());
			entries++;
			if (entries <= 5) {
				MyRecursiveAction a = new MyRecursiveAction();
				a.fork();
				tasks.add(a);
			}

			for (MyRecursiveAction action : tasks) {
				results.addAll(action.join());
			}

			return results;

		}

	}

}
