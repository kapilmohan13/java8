package com.mslc.training.reentrantlocks;

import java.lang.reflect.Field;

public class DeadLockIfLockIsNotReentrant {

	public static void main(String[] args) throws Exception {

		LocalCustomer customer1 = new LocalCustomer();

		Field f = LocalCustomer.class.getSuperclass().getDeclaredField("id");
		f.setAccessible(true);
		System.out.println(f.get(customer1));

	}
}

class Customer {

	private int id = 700;

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}

	public synchronized void addCustomer() {

		System.out.println("Id is : " + id);
	}

}

class LocalCustomer extends Customer {

	public synchronized void addCustomer() {

		System.out.println("addCustomer in Customer Class : " + this.getId());
		super.addCustomer();
	}
}
