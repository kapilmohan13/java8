package com.mslc.training.reordering;

/**
 * Consider the following <br>
 * <br>
 * <ol>
 * <li>
 * T1 upates the totalScore</li>
 * <li>
 * T2 - See if currentScoore == 0</li>
 * <li>T2 returns -1</li>
 * <li>T1 updates finalScore</li>
 * <li>T1 sets currentScore = 0</li>
 * </ol>
 * <em>Above race condition is still an acceptable situation</em> <br>
 * <br>
 * Now Consider the following<br>
 * <ol>
 * <li>T1 Updates totalScore</li>
 * <li>T1 Set currentScore = 0</li>
 * <li>T2 See if currentScore == 0</li>
 * <li>T2 Return finalScore</li>
 * <li>T1 Return finalScore</li>
 * </ol>
 * <em>In the above situation T2 has got the wrong value of final</em>
 * <br><br>
 * @author MuhammedShakir
 * 
 */
public class ReOrderingProblem {

	private int currentScore, totalScore, finalScore;

	public void resetScore(boolean done) {
		totalScore += currentScore;
		if (done) {
			finalScore = totalScore;
			currentScore = 0;
		}

	}

	public int getFinalScore() {
		if (currentScore == 0) {
			return finalScore;
		}
		return -1;
	}

}
