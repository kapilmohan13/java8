package com.mslc.training.visibility;

public class VisibilityProblem extends Thread {

	private boolean taskCompleted = false;

	public void run() {
		
		while (!taskCompleted) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
	public void setTaskCompleted() {
		taskCompleted = true;
	}

}
