package com.mslc.training.visibility;

public class NoVisibility {

	private static int stockValue;
	private static boolean updated;

	private static class StockDisplay extends Thread {

		@Override
		public void run() {

			while (!updated) {
				Thread.yield();
			}

			System.out.println(stockValue);
		}

	}

	public static void main(String[] args) throws InterruptedException {

		new StockDisplay().start();
		Thread.sleep(1000);

		stockValue = 400;
		updated = true;

	}

}
