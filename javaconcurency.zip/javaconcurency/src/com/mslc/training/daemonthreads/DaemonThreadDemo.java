package com.mslc.training.daemonthreads;

import java.util.Timer;

public class DaemonThreadDemo {

	public static void main(String[] args) {

		Timer timer = new Timer(false);

		System.out.println("timer created...");

	}
}
