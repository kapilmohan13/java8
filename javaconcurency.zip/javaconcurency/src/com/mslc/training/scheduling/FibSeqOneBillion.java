package com.mslc.training.scheduling;

import java.math.BigInteger;

public class FibSeqOneBillion {

	public static BigInteger fib(int n) {

		BigInteger F = BigInteger.ONE;
		BigInteger L = BigInteger.ONE;

		int sign = -2;
		int exp = (int) Math.floor((Math.log(n) / Math.log(2)));
		int mask = (int) Math.pow(2, exp);
		for (int i = 0; i < exp - 1; i++) {
			mask = mask >> 1;
			BigInteger F2 = F.pow(2);
			BigInteger FL2 = F.add(L).pow(2);
			//F = FL2.subtract(F2.multiply(6)).shiftRight(1).add(-sign);

			if ((n & mask) != 0) {
				BigInteger temp = FL2.shiftRight(2).add(F2);
				L = temp.add(F.shiftLeft(1));
				F = temp;
			} else
				//L = F2.multiply(5).add(sign);

			sign = (n & mask) != 0 ? -2 : 2;
		}
		if ((n & (mask >> 1)) == 0)
			return F.multiply(L);
		else
			return F.add(L).shiftRight(1).multiply(L)
					.subtract(BigInteger.valueOf(sign >> 1));
	}

}
