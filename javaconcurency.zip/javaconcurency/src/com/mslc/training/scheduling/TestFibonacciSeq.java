package com.mslc.training.scheduling;

public class TestFibonacciSeq {
	
	public static void main(String[] args) {
		
		int nThreads = Integer.parseInt(args[0]);
		long n = Long.parseLong(args[1]);
		Thread t[] = new Thread[nThreads];

		for (int i = 0; i < t.length; i++) {
			t[i] = new Thread(new FibonacciTask(n, "Task " + i));
			//System.out.println("Starting with priority : " + (i%10));
			//t[i].setPriority((i%10) + 1);
			t[i].start();
		}
		for (int i = 0; i < t.length; i++) {
			try {
				t[i].join();
			} catch (InterruptedException ie) {
			}
		}
		
	}

}
