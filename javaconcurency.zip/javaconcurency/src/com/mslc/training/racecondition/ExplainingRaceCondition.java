package com.mslc.training.racecondition;

import java.util.ArrayList;
import java.util.*;
import java.util.List;



public class ExplainingRaceCondition {

	private int c = 0;

	public int incrementAndGet() {

		c++;
		return c;
	}

}

class UnsafeCounterTest {
	volatile static boolean found = false;

	public static void main(String[] args) throws InterruptedException {

		final ExplainingRaceCondition counter = new ExplainingRaceCondition();

		final HashMap duplicateCounts = new HashMap();

		final List<Thread> threads = new ArrayList<>();
		int totalThreads = 5000;

		for (int count = 0; count < totalThreads; count++) {
			threads.add(new Thread() {

				@Override
				public void run() {
					int newValue = counter.incrementAndGet();

					if (duplicateCounts.put(newValue, newValue) != null) {
						System.out.println("*********************** Duplicate Value...");
					}
				}

			});
		}

		System.out.println("Size of List is : " + threads.size());
		for (int count = 0; count < threads.size(); count++) {
			threads.get(count).start();
		}

		for (int count = 0; count < threads.size(); count++) {
			threads.get(count).join();
		}
		for (int count = 1; count < threads.size() + 1; count++) {
			if (duplicateCounts.get(count) == null) {
				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> value : "
						+ count + " Not Found");
			} else {
				//System.out.println(duplicateCounts.get(count));
			}
		}
		System.out.println("Size of Map is : " + duplicateCounts.size());

	}
}
